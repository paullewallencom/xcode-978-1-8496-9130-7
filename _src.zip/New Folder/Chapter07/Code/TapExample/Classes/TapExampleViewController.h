//
//  TapExampleViewController.h
//  TapExample
//
//  Created by Steven F. Daniel on 8/01/11.
//  Copyright 2011 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TapExampleViewController : UIViewController {

    UILabel *tapCount;
}
@property (nonatomic, retain) IBOutlet UILabel *tapCount;

@end
