//
//  OrientationExampleViewController.h
//  OrientationExample
//
//  Created by Steven F Daniel on 16/01/11.
//  Copyright 2011 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrientationExampleViewController : UIViewController {

}

@end
