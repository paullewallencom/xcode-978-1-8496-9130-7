//
//  ShakeExampleViewController.h
//  ShakeExample
//
//  Created by Steven F. Daniel on 8/01/11.
//  Copyright 2011 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShakeExampleViewController : UIViewController {

}

@end
