//
//  HelloXcode4ViewController.h
//  HelloXcode4
//
//  Created by Steven F Daniel on 31/10/10.
//  Copyright (c) 2010 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HelloXcode4ViewController : UIViewController {
    
}

@end
