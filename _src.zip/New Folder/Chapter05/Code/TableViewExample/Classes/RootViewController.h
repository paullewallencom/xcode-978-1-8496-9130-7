//
//  RootViewController.h
//  TableViewExample
//
//  Created by Steven F. Daniel on 19/12/10.
//  Copyright 2010 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
    NSArray *arrVegetables;
}


@end
