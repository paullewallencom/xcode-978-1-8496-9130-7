//
//  MapKitSampleViewController.h
//  MapKitSample
//
//  Created by Steven F Daniel on 3/12/10.
//  Copyright 2010 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface MapKitSampleViewController : UIViewController {

    MKMapView *mapView;
}

@end
