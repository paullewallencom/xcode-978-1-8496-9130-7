//
//  MoviePlayerViewController.h
//  MoviePlayer
//
//  Created by Steven F Daniel on 2/12/10.
//  Copyright 2010 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface MoviePlayerViewController : UIViewController {
  
}
@end