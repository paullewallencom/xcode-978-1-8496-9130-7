//
//  main.m
//  HelloXcode4_GUI
//
//  Created by Steven F Daniel on 13/11/10.
//  Copyright (c) 2010 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
