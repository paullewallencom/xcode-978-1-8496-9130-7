//
//  main.m
//  MyDocument
//
//  Created by Steven F Daniel on 20/11/10.
//  Copyright (c) 2010 GenieSoft Studios. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]) {
    return NSApplicationMain(argc,  (const char **) argv);
}
