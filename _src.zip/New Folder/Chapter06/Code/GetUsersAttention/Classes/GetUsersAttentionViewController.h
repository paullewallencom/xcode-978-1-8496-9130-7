//
//  GetUsersAttentionViewController.h
//  GetUsersAttention
//
//  Created by Steven F Daniel on 27/12/10.
//  Copyright 2010 GenieSoft Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetUsersAttentionViewController : UIViewController <UIAlertViewDelegate, UIActionSheetDelegate>{
    UIAlertView *baseAlert;
}

@end
